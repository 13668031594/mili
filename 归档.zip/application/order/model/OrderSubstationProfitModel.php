<?php

namespace app\order\model;

use think\Model;

class OrderSubstationProfitModel extends Model
{
    //
}
