<?php

namespace app\express\model;

use think\Model;

class ExpressModel extends Model
{
    //
}
