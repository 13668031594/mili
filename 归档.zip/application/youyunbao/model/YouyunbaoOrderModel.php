<?php

namespace app\youyunbao\model;

use think\Model;

class YouyunbaoOrderModel extends Model
{
    //
}
