<?php

namespace app\youyunbao\model;

use think\Model;

class YouyunbaoPayModel extends Model
{
    //
}
