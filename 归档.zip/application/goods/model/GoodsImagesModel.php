<?php

namespace app\goods\model;

use think\Model;

class GoodsImagesModel extends Model
{
    //
}
