<?php

namespace app\goods\model;

use think\Model;

class GoodsRecordModel extends Model
{
    //
}
