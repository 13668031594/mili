<?php

namespace app\goods\model;

use think\Model;

class GoodsLevelAmountModel extends Model
{
    //
}
