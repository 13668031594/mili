<?php

namespace app\goods\model;

use think\Model;

class GoodsAmountModel extends Model
{
    //
}
