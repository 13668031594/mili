<?php

namespace app\goods\model;

use think\Model;

class GoodsClassModel extends Model
{
    //
}
