<?php

namespace app\article\model;

use think\Model;

class ArticleModel extends Model
{
    //
}
