<?php

namespace app\notice\model;

use think\Model;

class NoticeModel extends Model
{
    //
}
