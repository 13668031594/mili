<?php

namespace app\index\model;

use think\Model;

class SmsModel extends Model
{
    //
}
