<?php

namespace app\master\model;

use think\Model;

class MasterModel extends Model
{
    //
}
