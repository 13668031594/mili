<?php

namespace app\member\model;

use think\Model;

class MemberGradeAmountModel extends Model
{
    //
}
