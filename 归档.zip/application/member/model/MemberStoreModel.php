<?php

namespace app\member\model;

use think\Model;

class MemberStoreModel extends Model
{
    //
}
