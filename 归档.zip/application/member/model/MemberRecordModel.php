<?php

namespace app\member\model;

use think\Model;

class MemberRecordModel extends Model
{
    //
}
