<?php

namespace app\member\model;

use think\Model;

class MemberGradeModel extends Model
{
    //
}
