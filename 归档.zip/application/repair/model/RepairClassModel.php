<?php

namespace app\repair\model;

use think\Model;

class RepairClassModel extends Model
{
    //
}
