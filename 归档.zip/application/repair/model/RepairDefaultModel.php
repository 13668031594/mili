<?php

namespace app\repair\model;

use think\Model;

class RepairDefaultModel extends Model
{
    //
}
