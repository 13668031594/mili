<?php

namespace app\banner\model;

use think\Model;

class BannerImagesModel extends Model
{
    //
}
