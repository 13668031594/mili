<?php

namespace app\banner\model;

use think\Model;

class BannerModel extends Model
{
    //
}
