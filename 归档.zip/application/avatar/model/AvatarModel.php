<?php

namespace app\avatar\model;

use think\Model;

class AvatarModel extends Model
{
    //
}
