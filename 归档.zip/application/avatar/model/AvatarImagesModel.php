<?php

namespace app\avatar\model;

use think\Model;

class AvatarImagesModel extends Model
{
    //
}
