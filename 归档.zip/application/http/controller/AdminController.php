<?php

namespace app\http\controller;

use think\Request;

class AdminController extends FirstController
{
    protected $url = 'admin';
}
