<?php

namespace app\withdraw\model;

use think\Model;

class WithdrawModel extends Model
{
    //
}
