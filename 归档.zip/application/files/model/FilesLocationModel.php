<?php

namespace app\files\model;

use think\Model;

class FilesLocationModel extends Model
{

}
