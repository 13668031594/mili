<?php

namespace app\recharge\model;

use think\Model;

class RechargeModel extends Model
{
    //
}
