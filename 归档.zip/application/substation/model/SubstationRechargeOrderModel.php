<?php

namespace app\substation\model;

use think\Model;

class SubstationRechargeOrderModel extends Model
{
    //
}
