<?php

namespace app\substation\model;

use think\Model;

class SubstationRechargeModel extends Model
{
    //
}
