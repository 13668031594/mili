<?php

namespace app\substation\model;

use think\Model;

class SubstationModel extends Model
{
    //
}
