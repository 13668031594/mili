<?php

namespace app\substation\model;

use think\Model;

class SubstationRechargeRecordModel extends Model
{
    //
}
