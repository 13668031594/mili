<?php

namespace app\substation\model;

use think\Model;

class SubstationLevelUpModel extends Model
{
    //
}
