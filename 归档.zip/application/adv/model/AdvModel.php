<?php

namespace app\adv\model;

use think\Model;

class AdvModel extends Model
{
    //
}
