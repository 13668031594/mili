<?php

namespace app\adv\model;

use think\Model;

class AdvImagesModel extends Model
{
    //
}
