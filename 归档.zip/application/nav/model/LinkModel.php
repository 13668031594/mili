<?php

namespace app\nav\model;

use think\Model;

class LinkModel extends Model
{
    //
}
