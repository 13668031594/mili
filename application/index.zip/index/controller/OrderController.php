<?php
/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2018/11/27
 * Time: 下午1:44
 */

namespace app\index\controller;

use classes\index\OrderClass;
use think\Request;

class OrderController extends \app\http\controller\IndexController
{
    private $class;

    public function __construct()
    {
        parent::__construct();

        $this->class = new OrderClass();
    }

    //下单页面
    public function getOrder()
    {
        $goods_id = input('goodsId');

        $goods = $this->class->goods_info($goods_id);

        $store = $this->class->store();

        $express = $this->class->express();

        $result = [
            'store' => $store,
            'express' => $express,
            'goods' => $goods
        ];

        return parent::view('order', $result);
    }

    //下单
    public function postOrder(Request $request)
    {
        $address = $this->class->validator_order($request);

        $result = $this->class->save($request,$address);

        return parent::success('','操作成功',$result);
    }

    //已购礼品页面
    public function getGoodsHad()
    {
        $result = [
            'store' => $this->class->store()
        ];

        return parent::view('goods-had', $result);
    }

    //已购礼品数据
    public function getGoodsHadTable()
    {
        $result = $this->class->goods_had_table();

        return parent::tables($result);
    }
}